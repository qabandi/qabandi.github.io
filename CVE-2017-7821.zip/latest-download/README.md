# latest-download

## What it does ##

The extension includes a browser action with a popup.

When the user clicks the browser action button, the popup is shown.
The popup displays the most recent download, and has buttons to open the
file or to remove it.

If the user removes it, the file is removed from disk and from the browser's
downloads history.

## What it shows ##

* how to use various parts of the downloads API
